# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 19:18:18 2020

@author: Manuel Camargo
"""
import pandas as pd
import numpy as np
import utils.support as sup
import itertools
from operator import itemgetter
try:
    from support_modules import role_discovery as rl
except:
    import os
    from importlib import util
    spec = util.spec_from_file_location(
        'role_discovery', 
        os.path.join(os.getcwd(), 'support_modules', 'role_discovery.py'))
    rl = util.module_from_spec(spec)
    spec.loader.exec_module(rl)

class FeaturesMannager():


    def __init__(self, params):
        """constructor"""
        self.model_type = params['model_type']
        self.one_timestamp = params['one_timestamp']
        # self.resources = pd.DataFrame
        self.norm_method = params['norm_method']
        self._scalers = dict()
        self.scale_dispatcher = {'basic': self._scale_base,
                                 'inter': self._scale_inter}

    def calculate(self, log, add_cols):
        log = self.add_calculated_times(log)
        log = self.filter_features(log, add_cols)
        return self.scale_features(log, add_cols)

    @staticmethod
    def add_resources(log, rp_sim):
        # Resource pool discovery
        res_analyzer = rl.ResourcePoolAnalyser(log, sim_threshold=rp_sim)
        # Role discovery
        resources = pd.DataFrame.from_records(res_analyzer.resource_table)
        resources = resources.rename(index=str,
                                               columns={"resource": "user"})
        # Add roles information
        log = log.merge(resources, on='user', how='left')
        log = log[~log.task.isin(['Start', 'End'])]
        log = log.reset_index(drop=True)
        return log

    def filter_features(self, log, add_cols):
        # Add intercase features
        columns = ['caseid', 'task', 'user', 'end_timestamp', 
                   'role', 'dur', 'ac_index',  'rl_index']
        if not self.one_timestamp:
            columns.extend(['start_timestamp', 'wait'])
        columns.extend(add_cols)
        log = log[columns]
        return log

    @staticmethod
    def get_inter_arrival_time_case(log):

        # Ensure start_timestamp is in datetime format
        log['start_timestamp'] = pd.to_datetime(log['start_timestamp'])

        # Initialize the inter-arrival time column
        log['inter_arrival_time'] = 0

        # Extract unique cases and their start times
        start_times = log.groupby('caseid')['start_timestamp'].min().reset_index()
        start_times = start_times.sort_values(by='start_timestamp')

        # Calculate inter-arrival time for each case
        start_times['inter_arrival_time'] = start_times['start_timestamp'].diff().dt.total_seconds().fillna(0)

        # Map inter-arrival times to the original log
        inter_arrival_map = dict(zip(start_times['caseid'], start_times['inter_arrival_time']))
        log['inter_arrival_time'] = log['caseid'].map(inter_arrival_map)

        return log


    @staticmethod
    def get_active_cases(current_time, log):
        if isinstance(log, list):
            log = pd.DataFrame(log)
        # get the cases that are active at the current time
        active = log[(log['start_timestamp'] <= current_time) & (log['end_timestamp'] > current_time)]
        # get unique caseids
        active = active.drop_duplicates(subset='caseid')

        active_log = log[(log['start_timestamp'] <= current_time) & (log['end_timestamp'] > current_time)]
        return active, active_log

    @staticmethod
    def get_resource_availability(log, parms, resource_counts):
        if not parms['one_timestamp']:
            # Precompute resource counts for all events
            resource_counts_dict = resource_counts.set_index('ac_index')['unique_resource_count'].to_dict()

            events = log.to_dict('records')
            events = sorted(events, key=lambda x: x['caseid'])
            total_events = len(events)
            sup.print_progress(0, 'Analysing available resources')
            for i, event in enumerate(events):
                event_start_time = event['start_timestamp']
                active, active_log = FeaturesMannager.get_active_cases(event_start_time, log)
                event['active_cases_len'] = len(active)

                # Calculate locked resources
                locked_resources = active_log.groupby('ac_index').size().reset_index(name='locked_resources')
                locked_resources.columns = ['ac_index', 'locked_resources']
                locked_resources_dict = locked_resources.set_index('ac_index')['locked_resources'].to_dict()

                # Get total resources for the current activity
                ac_index = event['ac_index']
                total_resources = resource_counts_dict.get(ac_index, 0)
                event['total_resources'] = total_resources

                # Calculate available resources
                locked = locked_resources_dict.get(ac_index, 0)
                available_and_not_locked = max(total_resources - locked, 0)
                event['available_resources'] = available_and_not_locked

                # Update progress
                progress = ((i + 1) / total_events) * 100
                sup.print_progress(progress, 'Analysing available resources')
                # Convert events back to DataFrame
            log = pd.DataFrame(events)

        return log


    def add_calculated_times(self, log):
        """Appends the indexes and relative time to the dataframe.
        parms:
            log: dataframe.
        Returns:
            Dataframe: The dataframe with the calculated features added.
        """
        log['dur'] = 0
        log['acc_cycle'] = 0
        log['daytime'] = 0
        log = log.to_dict('records')
        log = sorted(log, key=lambda x: x['caseid'])
        for _, group in itertools.groupby(log, key=lambda x: x['caseid']):
            events = list(group)
            ordk = 'end_timestamp' if self.one_timestamp else 'start_timestamp'
            events = sorted(events, key=itemgetter(ordk))
            for i in range(0, len(events)):
                # In one-timestamp approach the first activity of the trace
                # is taken as instantsince there is no previous timestamp
                # to find a range
                if self.one_timestamp:
                    if i == 0:
                        dur = 0
                        acc = 0
                    else:
                        dur = (events[i]['end_timestamp'] -
                               events[i-1]['end_timestamp']).total_seconds()
                        acc = (events[i]['end_timestamp'] -
                               events[0]['end_timestamp']).total_seconds()
                else: #going to change this part dur and waiting time
                    dur = (events[i]['end_timestamp'] -
                           events[i]['start_timestamp']).total_seconds()
                    acc = (events[i]['end_timestamp'] -
                           events[0]['start_timestamp']).total_seconds()
                    if i == 0:
                        wit = 0
                    else:
                        wit = (events[i]['start_timestamp'] -
                               events[i-1]['start_timestamp']).total_seconds()
                    events[i]['wait'] = wit if wit >= 0 else 0
                events[i]['dur'] = dur
                events[i]['acc_cycle'] = acc
                time = events[i][ordk].time()
                time = time.second + time.minute*60 + time.hour*3600
                events[i]['daytime'] = time
                if self.one_timestamp:
                    events[i]['weekday'] = events[i]['end_timestamp'].weekday()
                else:
                    events[i]['weekday'] = events[i]['start_timestamp'].weekday()
        return pd.DataFrame.from_dict(log)

    def scale_features(self, log, add_cols):
        scaler = self._get_scaler(self.model_type)
        return scaler(log, add_cols)

    def register_scaler(self, model_type, scaler):
        try:
            self._scalers[model_type] = self.scale_dispatcher[scaler]
        except KeyError:
            raise ValueError(scaler)

    def _get_scaler(self, model_type):
        scaler = self._scalers.get(model_type)
        if not scaler:
            raise ValueError(model_type)
        return scaler

    def _scale_base(self, log, add_cols):
        if self.one_timestamp:
            log, scale_args = self.scale_feature(log, 'dur', self.norm_method)
        else:
            log, dur_scale = self.scale_feature(log, 'dur', self.norm_method)
            log, wait_scale = self.scale_feature(log, 'wait', self.norm_method)
            scale_args = {'dur': dur_scale, 'wait': wait_scale}
        return log, scale_args

    def _scale_inter(self, log, add_cols):
        # log, scale_args = self.scale_feature(log, 'dur', self.norm_method)
        if self.one_timestamp:
            log, scale_args = self.scale_feature(log, 'dur', self.norm_method)
        else:
            log, dur_scale = self.scale_feature(log, 'dur', self.norm_method)
            log, wait_scale = self.scale_feature(log, 'wait', self.norm_method)
            scale_args = {'dur': dur_scale, 'wait': wait_scale}
        for col in add_cols:
            if col == 'daytime':
                log, _ = self.scale_feature(log, 'daytime', 'day_secs', True)
            elif col == 'weekday':
                continue
            else:
                log, _ = self.scale_feature(log, col, self.norm_method, True)
        return log, scale_args

    # =========================================================================
    # Scale features
    # =========================================================================
    @staticmethod
    def scale_feature(log, feature, method, replace=False):
        """Scales a number given a technique.
        Args:
            log: Event-log to be scaled.
            feature: Feature to be scaled.
            method: Scaling method max, lognorm, normal, per activity.
            replace (optional): replace the original value or keep both.
        Returns:
            Scaleded value between 0 and 1.
        """
        scale_args = dict()
        if method == 'lognorm':
            log[feature + '_log'] = np.log1p(log[feature])
            max_value = np.max(log[feature+'_log'])
            min_value = np.min(log[feature+'_log'])
            log[feature+'_norm'] = np.divide(
                    np.subtract(log[feature+'_log'], min_value), (max_value - min_value))
            log = log.drop((feature + '_log'), axis=1)
            scale_args = {'max_value': max_value, 'min_value': min_value}
        elif method == 'normal':
            max_value = np.max(log[feature])
            min_value = np.min(log[feature])
            log[feature+'_norm'] = np.divide(
                    np.subtract(log[feature], min_value), (max_value - min_value))
            scale_args = {'max_value': max_value, 'min_value': min_value}
        elif method == 'standard':
            mean = np.mean(log[feature])
            std = np.std(log[feature])
            log[feature + '_norm'] = np.divide(np.subtract(log[feature], mean),
                                               std)
            scale_args = {'mean': mean, 'std': std}
        elif method == 'max':
            max_value = np.max(log[feature])
            log[feature + '_norm'] = (np.divide(log[feature], max_value)
                                      if max_value > 0 else 0)
            scale_args = {'max_value': max_value}
        elif method == 'day_secs':
            max_value = 86400
            log[feature + '_norm'] = (np.divide(log[feature], max_value)
                                      if max_value > 0 else 0)
            scale_args = {'max_value': max_value}
        elif method is None:
            log[feature+'_norm'] = log[feature]
        else:
            raise ValueError(method)
        if replace:
            log = log.drop(feature, axis=1)
        return log, scale_args
